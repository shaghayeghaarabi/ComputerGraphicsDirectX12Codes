#include <iostream>

#define SIZE 4

class Determinant {
private:
    int matrix[SIZE][SIZE];

public:
    Determinant(int arr[SIZE][SIZE]) {
        for (int i = 0; i < SIZE; i++) {
            for (int j = 0; j < SIZE; j++) {
                matrix[i][j] = arr[i][j];
            }
        }
    }

    int calculateDeterminant() {
        int det = 0;

        for (int i = 0; i < SIZE; i++) {
            det += (matrix[0][i] * (matrix[1][(i + 1) % SIZE] * matrix[2][(i + 2) % SIZE] - matrix[1][(i + 2) % SIZE] * matrix[2][(i + 1) % SIZE]));
        }

        return det;
    }
    void displayMatrix() {
        for (int i = 0; i < SIZE; i++) {
            std::cout << "|" << "\t";
            for (int j = 0; j < SIZE; j++) {
                std::cout << matrix[i][j] << " \t";
            }
            std::cout << "\t" << "|";
            std::cout << std::endl;
        }
    }
};

