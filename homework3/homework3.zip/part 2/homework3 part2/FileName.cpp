#include <iostream>
#include "Determinant.h"
#include "Transpose.h"
using namespace std;
#define n 4
int main() {
    int arr[n][n];
    
    cout << "plese enter array" << "\n";
    cout << "row" << "\t" << "|" << "\t" << "column" << "\t" << "|\n";
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < n; j++) {
            cout << i << "\t" << "|" << "\t" << j << "\t" << "|";
            cin >> arr[i][j];
        }
        cout << "\n";
    }
    Determinant a(arr);
    Transpose z(arr);
    cout << "matrix is:\n" << "\n";
    z.displayMatrix();
    cout << "\n";
    cout <<"determinant is:" << a.calculateDeterminant() << "\n\n";
    cout << "transpose is \n";
    z.transposeMatrix();
    return 0;
}