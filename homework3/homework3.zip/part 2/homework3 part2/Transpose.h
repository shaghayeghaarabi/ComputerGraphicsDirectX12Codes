#include <iostream>

#define SIZE 4

class Transpose {
private:
    int matrix[SIZE][SIZE];

public:
    Transpose(int arr[SIZE][SIZE]) {
        for (int i = 0; i < SIZE; i++) {
            for (int j = 0; j < SIZE; j++) {
                matrix[i][j] = arr[i][j];
            }
        }
    }

    void transposeMatrix() {
        for (int i = 0; i < SIZE; i++) {
            for (int j = i + 1; j < SIZE; j++) {
                int temp = matrix[j][i];
                matrix[j][i] = matrix[i][j];
                matrix[i][j] = temp;

            }
        }
        for (int i = 0; i < SIZE; i++) {
            std::cout << "|" << "\t";
            for (int j = 0; j < SIZE; j++) {
                std::cout << matrix[i][j] << "\t";
            }
            std::cout << "\t" << "|";
            std::cout << std::endl;
        }
    }

    void displayMatrix() {
        for (int i = 0; i < SIZE; i++) {
            std::cout << "|" << "\t";
            for (int j = 0; j < SIZE; j++) {
                std::cout << matrix[i][j] << "\t";
            }
            std::cout << "\t" << "|";
            std::cout << std::endl;
        }
    }
};

