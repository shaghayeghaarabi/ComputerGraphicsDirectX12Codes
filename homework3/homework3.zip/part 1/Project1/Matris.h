#include <iostream>
const int n = 4;
using namespace std;

class Matris
{

private:
    int mat[n][n];

public:
    // Constructor
    Matris() {
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n; j++) {
                mat[i][j] = 0;
            }
        }
    }

    // Overloaded constructor
    Matris(int arr[n][n]) {
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n; j++) {
                mat[i][j] = arr[i][j];
            }
        }
    }

    // Overloaded + operator
    Matris operator+(Matris m) {
        Matris result;
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n; j++) {
                result.mat[i][j] = mat[i][j] + m.mat[i][j];
            }
        }
        return result;
    }

    // Overloaded - operator
    Matris operator-(Matris m) {
        Matris result;
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n; j++) {
                result.mat[i][j] = mat[i][j] - m.mat[i][j];
            }
        }
        return result;
    }

    // Overloaded * operator
    Matris operator*(Matris m) {
        Matris result;
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n; j++) {
                int sum = 0;
                for (int k = 0; k < 4; k++) {
                    sum += mat[i][k] * m.mat[k][j];
                }
                result.mat[i][j] = sum;
            }
        }
        return result;
    }

    // Display the matrix
    void display() {
        for (int i = 0; i < n; i++) {
            cout << "|" << "\t";
            for (int j = 0; j < n; j++) {
                cout << mat[i][j] << "\t" << "," << "\t";
            }
            cout << "\t\t" << "|";
            cout << endl;
        }
    }
};

