#include <iostream>
#include "Matris.h"
#define n 4
using namespace std;
int main() {
    int arr1[n][n];
    int arr2[n][n];
    Matris a;
    Matris b;
    Matris c;
    cout << "plese enter array1" << "\n";
    cout << "row" << "\t" << "|" << "\t" << "column" << "\t" << "|\n";
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < n; j++) {
            cout << i << "\t" << "|" << "\t" << j << "\t" << "|";
            cin >> arr1[i][j];
        }
        cout << "\n";
    }
    a = arr1;
    cout << "array1 is:\n";
    a.display();
    cout << "plese enter array2" << "\n";
    cout << "row" << "\t" << "|" << "\t" << "column" << "\t" << "|\n";
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < n; j++) {
            cout << i << "\t" << "|" << "\t" << j << "\t" << "|";
            cin >> arr2[i][j];
        }
        cout << "\n";
    }
    b = arr2;
    cout << "array2 is:\n";
    b.display();
    cout << "arra1 + array2:\n";
    c = a.operator+(b);
    c.display();
    cout << "arra1 - array2:\n";
    c = a.operator-(b);
    c.display();
    cout << "arra2 - array1:\n";
    c = b.operator-(a);
    c.display();
    cout << "arra1 * array2:\n";
    c = a.operator*(b);
    c.display();
    cout << "arra2 * array1:\n";
    c = b.operator*(a);
    c.display();

    return 0;
}